#########################################
#  __  __   __            __        _   #
# |   |  | |  | |  | |   |  | |  | | \  #
# |__ |__| |_/  |  | |   |__| |\ | |  | #
# |   |  | | \  |  | |   |  | | \| |  | #
# |   |  | |__| |__| |__ |  | |  | |_/  #
#                                       #
#########################################

Welcome to Middle-Earth !

The purpose of this resource pack is to turn minecraft into a more LOTR-themed game without heavy mods.
It modifies the textures of essential blocks, items and entities to do so.
In order to fully appreciate the pack, you will need to be using Optifine, or equivalents with Fabric (Continuity, CEM,...)
Also make sure to play in english so that the modified 'en_us.json' file can change names, so that it all makes sense.

Note that, for the moment, the pack doesn't have custom musics or sounds, but that these are planned for the future.

Here are a few examples of things that are modified by the pack :

•    Plains ➡ Shire; Taiga & Snowy Plains ➡ Gondor; Savanna ➡ Rohan...
•    Pillagers ➡ Uruk-Hai; Wandering Traders ➡ Dwarf Merchants; Endermen ➡ Elves...
•    Nether ➡ Mordor; End ➡ Utumno...
•    And plenty more to discover ;)

Enjoy playing Minecraft with Lord Of The Packs !
Fabuland

#########################################

NB: To recreate the map of Middle-Earth displayed on the online screenshots from the pack you need to go back to the default textures and 
put all the paintings as shown in the 'MAP_MODEL.png' file.

#########################################

Lord Of The Packs [1.4]:The Good Old Days !
Changelog :

•    Turned the new copper items and armor into Rohirric stuff
•    Made new biome-specific paths using connected textures 
•    Entirely reworked the GUI with a new custom theme to fit the pack
•    Improved the Hobbit doors by modifying their 3d models
•    Added a lot more of alternate textures for villager skins
•    Improved the map of Middle-Earth made with paintings
•    Fixed a lot of things here and there...